import { FileText, Download } from 'lucide-react'
import { toast } from 'sonner'
import type { Project } from '@/types'
import { useProjectStore } from '@/store/projectStore'
import { calculateCostSummary } from '@/lib/calculations'
import { formatCurrency } from '@/lib/utils'

interface Props { project: Project }

export default function ReportsTab({ project }: Props) {
  const { costItems, risks, financialSettings } = useProjectStore()
  const currency = financialSettings?.currency || 'USD'

  const summary = calculateCostSummary(
    costItems,
    financialSettings || { id: '', project_id: project.id, overhead_pct: 10, contingency_pct: 5, markup_pct: 15, tax_pct: 5, currency: 'USD' },
    risks
  )

  const generateReport = (type: 'proposal' | 'breakdown') => {
    // Simple text-based report generation
    const now = new Date().toLocaleDateString()
    let content = ''

    if (type === 'proposal') {
      content = `
CONSTRUCTION COST PROPOSAL
===========================
Project: ${project.name}
Date: ${now}
Location: ${project.location || 'N/A'}
Type: ${project.type || 'N/A'}
Duration: ${project.duration ? `${project.duration} ${project.duration_unit}` : 'N/A'}

CLIENT REQUIREMENTS:
${project.client_requirements || 'N/A'}

DESCRIPTION:
${project.description || 'N/A'}

============================
GRAND TOTAL: ${formatCurrency(summary.grandTotal, currency)}
============================
      `
    } else {
      content = `
CONSTRUCTION COST BREAKDOWN
============================
Project: ${project.name}
Date: ${now}

COST SUMMARY:
Materials:    ${formatCurrency(summary.materialsCost, currency)}
Labor:        ${formatCurrency(summary.laborCost, currency)}
Equipment:    ${formatCurrency(summary.equipmentCost, currency)}
Additional:   ${formatCurrency(summary.additionalCost, currency)}
--------------------------
Direct Cost:  ${formatCurrency(summary.directCost, currency)}
Overhead:     ${formatCurrency(summary.overhead, currency)}
Contingency:  ${formatCurrency(summary.contingency, currency)}
Subtotal:     ${formatCurrency(summary.subtotal, currency)}
Markup:       ${formatCurrency(summary.markup, currency)}
Tax:          ${formatCurrency(summary.tax, currency)}
==========================
GRAND TOTAL:  ${formatCurrency(summary.grandTotal, currency)}
      `
    }

    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${project.name.replace(/\s+/g, '_')}_${type}.txt`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Report downloaded!')
  }

  const reports = [
    {
      type: 'proposal' as const,
      title: 'Proposal Report',
      description: 'Client-facing proposal with project overview and grand total',
      icon: <FileText size={24} className="text-accent" />,
    },
    {
      type: 'breakdown' as const,
      title: 'Cost Breakdown Report',
      description: 'Detailed itemized breakdown of all cost categories',
      icon: <FileText size={24} className="text-success" />,
    },
  ]

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold text-white">Reports</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {reports.map(report => (
          <div key={report.type} className="card hover:border-accent/30 transition-all">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-white/5 rounded-xl">{report.icon}</div>
              <div className="flex-1">
                <h3 className="font-semibold text-white">{report.title}</h3>
                <p className="text-surface-muted text-sm mt-1">{report.description}</p>
                <button
                  onClick={() => generateReport(report.type)}
                  className="btn-outline btn-sm mt-4 gap-1.5"
                >
                  <Download size={13} /> Download
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
