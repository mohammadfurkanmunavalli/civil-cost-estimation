import { Clock } from 'lucide-react'

interface Props { projectId: string }

export default function VersionsTab({ projectId: _ }: Props) {
  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-4">
        <Clock size={18} className="text-accent" />
        <h2 className="text-lg font-semibold text-white">Version History</h2>
      </div>
      <div className="text-center py-12 text-surface-muted">
        <Clock size={40} className="mx-auto mb-3 opacity-30" />
        <p className="text-sm">No versions saved yet.</p>
        <p className="text-xs mt-1">Version snapshots will appear here when saved.</p>
      </div>
    </div>
  )
}
